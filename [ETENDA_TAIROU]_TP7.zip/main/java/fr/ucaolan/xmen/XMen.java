package fr.ucaolan.xmen;

import androidx.annotation.DrawableRes;

import io.realm.Realm;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.RealmClass;
import io.realm.annotations.Required;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@ToString
public class XMen extends RealmObject {

    @PrimaryKey
    private long id;
    @Setter
    @Required
    private String nom;
    @Setter
    @Required
    private String alias;
    @Setter
    @Required
    private String description;
    @Setter
    @Required
    private String pouvoirs;
    @Setter
    private @DrawableRes int idImage;

    public XMen()
    {
        nom = "inconnu";
        alias = "inconnu";
        description = "inconnu";
        pouvoirs = "inconnu";
        this.idImage = R.drawable.undef;
    }

    public static long getNextID(Realm realm){
        Number max = realm.where(XMen.class).max(XMenFields.ID);
        if(max == null) return 1L;
        else return max.longValue() + 1L;
    }

}
