package fr.ucaolan.xmen;


import android.app.Application;
import android.content.res.Resources;
import android.content.res.TypedArray;

import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;

public class XMenApplication extends Application
{

    @Override
    public void onCreate() {
        super.onCreate();
        Realm.init(this);
//        initListe();
    }

    public void initListe()
    {
        Resources res = getResources();
        final String[] noms = res.getStringArray(R.array.noms);
        final String[] alias = res.getStringArray(R.array.alias);
        final String[] description = res.getStringArray(R.array.descriptions);
        final String[] pouvoirs = res.getStringArray(R.array.pouvoirs);

        TypedArray images = res.obtainTypedArray(R.array.idimages);

        Realm realm = Realm.getDefaultInstance();

        realm.beginTransaction();

        realm.where(XMen.class).findAll().deleteAllFromRealm();

        for (int i = 0; i < noms.length; i++)
        {
            XMen xmen = realm.createObject(XMen.class, XMen.getNextID(realm));
            xmen.setNom(noms[i])
                    .setAlias(alias[i])
                    .setDescription(description[i])
                    .setPouvoirs(pouvoirs[i])
                    .setIdImage(images.getResourceId(i, R.drawable.undef));
        }
        realm.commitTransaction();

        images.recycle();
    }
}