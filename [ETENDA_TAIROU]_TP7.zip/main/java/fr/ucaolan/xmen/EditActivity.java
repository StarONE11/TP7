package fr.ucaolan.xmen;

import androidx.annotation.DrawableRes;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import java.util.List;

import fr.ucaolan.xmen.databinding.ActivityEditBinding;
import fr.ucaolan.xmen.databinding.ActivityMainBinding;
import io.realm.Realm;
import io.realm.RealmResults;

public class EditActivity extends AppCompatActivity {

    public static final String EXTRA_ID = "id";
    private ActivityEditBinding ui;

    private Realm realm;
    private long id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ui = ActivityEditBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());

        realm = Realm.getDefaultInstance();

        Intent intent = getIntent();
        id = intent.getLongExtra(EXTRA_ID, -1L);

        if (id >= 0){
            XMen xmen = realm.where(XMen.class).equalTo(XMenFields.ID, id).findFirst();
            setXMen(xmen);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.edit_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onDestroy() {
        realm.close();
        super.onDestroy();
    }

    public void onAccept(MenuItem item)
    {
        realm.beginTransaction();

        XMen xmen;

        if (id < 0)
        {
            xmen = realm.createObject(XMen.class, XMen.getNextID(realm));
        }
        else
        {
            xmen = realm.where(XMen.class).equalTo(XMenFields.ID, id).findFirst();
        }

        assert xmen != null;

        xmen.setNom(ui.editXMenName.getText().toString());
        xmen.setAlias(ui.editXMenAlias.getText().toString());
        xmen.setPouvoirs(ui.editXMenPwr.getText().toString());
        xmen.setDescription(ui.editXMenDesc.getText().toString());

        if (id < 0) xmen.setIdImage(R.drawable.undef);

        realm.commitTransaction();

        setResult(RESULT_OK);
        finish();
    }

    public void setXMen(@Nullable XMen xmen)
    {
        if (xmen == null) return;
        ui.editXMenName.setText(xmen.getNom());
        ui.editXMenAlias.setText(xmen.getAlias());
        ui.editXMenDesc.setText(xmen.getDescription());
        ui.editXMenPwr.setText(xmen.getPouvoirs());
        ui.editXMenImage.setImageResource(xmen.getIdImage());
    }
}